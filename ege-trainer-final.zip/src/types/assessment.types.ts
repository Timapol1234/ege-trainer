// src/types/assessment.types.ts
export interface AssessmentQuestion {
  id: string;
  type: 'multiple-choice' | 'text-input';
  question: string;
  options?: string[];
  correctAnswer: string;
  explanation: string;
  theme: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
}

export interface ThemeBreakdown {
  theme: string;
  correct: number;
  total: number;
  percentage: number;
  points: number;
}

export interface AssessmentResult {
  estimatedScore: number;
  totalCorrect: number;
  totalQuestions: number;
  themeBreakdown: ThemeBreakdown[];
  recommendedFocus: string[];
  preparationLevel: 'beginner' | 'intermediate' | 'advanced';
  totalPoints: number;
  maxPossiblePoints: number;
  weakAreas?: string[];
  timestamp?: number;
}

export interface UserResponse {
  questionId: string;
  selectedAnswer: string;
  timeSpent: number;
  theme: string;
}
export interface TemporaryAssessmentStorage {
  result: AssessmentResult;
  userGoals?: {
    targetScore: number;
    intensity: 'low' | 'medium' | 'high';
    currentScore: number;
  };
}