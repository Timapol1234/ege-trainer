// src/types/plan.ts

export interface WeekPlan {
  weekNumber: number;
  themes: string[];
  tasks: string[];
  practiceHours: number;
  goals: string[];
  resources: string[];
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface Resource {
  id: string;
  type: 'textbook' | 'video' | 'practice' | 'test' | 'interactive';
  title: string;
  description: string;
  url: string;
  duration: string;
  theme: string;
  difficulty: 'easy' | 'medium' | 'hard';
}

export interface PlanGenerationData {
  // Данные из регистрации
  initialScore: number;        // Текущий балл при регистрации
  targetScore: number;         // Желаемый балл
  
  // Данные из тестирования
  weakThemes: string[];        // Слабые темы из теста
  strongThemes: string[];      // Сильные темы из теста
  testScore: number;           // Результат тестирования в %
  
  // Дополнительные параметры
  availableHoursPerWeek: number;
  examDate: Date;
  userLevel: string;
  subjects: string[];          // Предметы для изучения
}

export interface StudyPlan {
  id: string;
  title: string;
  description: string;
  durationWeeks: number;
  focusAreas: string[];
  weeklySchedule: WeekPlan[];
  resources: Resource[];
  goals: string[];
  estimatedCompletion: Date;
  targetScore: number;
  currentScore: number;        // Текущий балл из регистрации
  testScore: number;           // Результат тестирования
  progress: number;            // Общий прогресс (0-100)
  intensity: 'low' | 'medium' | 'high'; // Интенсивность плана
  createdAt: Date;
}

// Типы для отображения прогресса
export interface StudyProgress {
  weekNumber: number;
  completedTasks: number;
  totalTasks: number;
  themesCompleted: string[];
  scoreImprovement: number;
  timeSpent: number; // в часах
}

// Типы для ресурсов обучения
export interface LearningResource {
  id: string;
  title: string;
  type: 'article' | 'video' | 'exercise' | 'test' | 'interactive';
  subject: string;
  topic: string;
  difficulty: 'beginner' | 'intermediate' | 'advanced';
  duration: number; // в минутах
  url: string;
  completed?: boolean;
}

// Типы для целей обучения
export interface LearningGoal {
  id: string;
  title: string;
  description: string;
  targetDate: Date;
  progress: number;
  type: 'score' | 'topic' | 'skill';
  metric: string;
  currentValue: number;
  targetValue: number;
}