// src/context/index.ts
export * from './AppContext';