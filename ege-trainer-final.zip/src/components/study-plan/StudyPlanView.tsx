// components/study-plan/StudyPlanView.tsx
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { StudyPlan, WeekPlan, Resource } from '@/types/plan';
import { useState, useMemo } from 'react';

interface StudyPlanViewProps {
  plan: StudyPlan | null;
  onAccept: () => void;
  onRegenerate?: () => void;
  loading?: boolean;
}

export const StudyPlanView: React.FC<StudyPlanViewProps> = ({ 
  plan, 
  onAccept, 
  onRegenerate,
  loading = false
}) => {
  const [activeWeek, setActiveWeek] = useState<number>(1);

  if (loading) {
    return (
      <Card className="max-w-6xl w-full mx-auto p-8 text-center">
        <div className="text-gray-500">Генерируем ваш персональный план обучения...</div>
      </Card>
    );
  }

  if (!plan) {
    return (
      <Card className="max-w-6xl w-full mx-auto p-8 text-center">
        <div className="text-gray-500">План обучения не загружен</div>
        {onRegenerate && (
          <Button onClick={onRegenerate} className="mt-4">
            Сгенерировать план
          </Button>
        )}
      </Card>
    );
  }

  const activeWeekPlan = useMemo(() => 
    plan.weeklySchedule.find(w => w.weekNumber === activeWeek) || plan.weeklySchedule[0],
    [plan.weeklySchedule, activeWeek]
  );

  const totalPracticeHours = useMemo(() => 
    plan.weeklySchedule.reduce((acc, week) => acc + (week.practiceHours || 0), 0),
    [plan.weeklySchedule]
  );

  const filteredResources = useMemo(() => {
    if (!plan.resources || !activeWeekPlan?.topics) return [];
    
    return plan.resources.filter(resource => 
      resource.topics?.some(topic => 
        activeWeekPlan.topics.includes(topic)
      )
    ).slice(0, 4);
  }, [plan.resources, activeWeekPlan]);

  return (
    <Card className="max-w-6xl w-full mx-auto border-0 shadow-lg rounded-2xl overflow-hidden">
      {/* Заголовок с прогрессом */}
      <div className="bg-gradient-to-br from-green-50 to-blue-50 px-6 py-6 border-b">
        <div className="text-center mb-4">
          <h1 className="text-2xl font-bold text-gray-900 mb-2">
            {plan.title}
          </h1>
          <p className="text-gray-600 max-w-2xl mx-auto">
            {plan.description}
          </p>
        </div>

        {/* Статистика */}
        <div className="grid grid-cols-2 md:grid-cols-5 gap-4 max-w-3xl mx-auto">
          <div className="text-center bg-white rounded-lg p-3 shadow-sm">
            <div className="text-2xl font-bold text-blue-600">{plan.durationWeeks}</div>
            <div className="text-xs text-gray-600">недель</div>
          </div>
          <div className="text-center bg-white rounded-lg p-3 shadow-sm">
            <div className="text-2xl font-bold text-green-600">{plan.focusAreas.length}</div>
            <div className="text-xs text-gray-600">фокусных тем</div>
          </div>
          <div className="text-center bg-white rounded-lg p-3 shadow-sm">
            <div className="text-2xl font-bold text-purple-600">{totalPracticeHours}</div>
            <div className="text-xs text-gray-600">часов практики</div>
          </div>
          <div className="text-center bg-white rounded-lg p-3 shadow-sm">
            <div className="text-lg font-bold text-orange-600">{plan.currentScore}→{plan.targetScore}</div>
            <div className="text-xs text-gray-600">цель по баллам</div>
          </div>
          <div className="text-center bg-white rounded-lg p-3 shadow-sm">
            <div className="text-sm font-bold text-red-600 capitalize">{plan.intensity}</div>
            <div className="text-xs text-gray-600">интенсивность</div>
          </div>
        </div>
      </div>

      <div className="p-6">
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Навигация по неделям */}
          <div className="lg:col-span-1">
            <div className="bg-gray-50 rounded-xl p-4">
              <h3 className="font-semibold text-gray-900 mb-3">План по неделям</h3>
              <div className="space-y-2 max-h-96 overflow-y-auto">
                {plan.weeklySchedule.map(week => (
                  <button
                    key={week.weekNumber}
                    onClick={() => setActiveWeek(week.weekNumber)}
                    className={`w-full text-left p-3 rounded-lg transition-colors ${
                      activeWeek === week.weekNumber
                        ? 'bg-blue-100 border border-blue-200'
                        : 'bg-white hover:bg-gray-100 border border-gray-200'
                    }`}
                  >
                    <div className="font-medium text-sm">Неделя {week.weekNumber}</div>
                    <div className="text-xs text-gray-600 mt-1">
                      {week.themes?.slice(0, 2).join(', ') || 'Темы не указаны'}
                    </div>
                    <div className="text-xs text-blue-600 mt-1">
                      {week.practiceHours} часов практики
                    </div>
                  </button>
                ))}
              </div>
            </div>

            {/* Цели плана */}
            <div className="bg-gradient-to-br from-purple-50 to-pink-50 rounded-xl p-4 mt-4">
              <h3 className="font-semibold text-gray-900 mb-3">Цели плана</h3>
              <ul className="space-y-2">
                {(plan.goals || []).map((goal, index) => (
                  <li key={index} className="flex items-start space-x-2 text-sm">
                    <span className="text-green-600 mt-0.5">✓</span>
                    <span className="text-gray-700">{goal}</span>
                  </li>
                ))}
                {(!plan.goals || plan.goals.length === 0) && (
                  <li className="text-sm text-gray-500">Цели не указаны</li>
                )}
              </ul>
            </div>

            {/* Фокусные темы */}
            <div className="bg-gradient-to-br from-orange-50 to-yellow-50 rounded-xl p-4 mt-4">
              <h3 className="font-semibold text-gray-900 mb-3">Фокусные темы</h3>
              <div className="flex flex-wrap gap-2">
                {plan.focusAreas.map((topic, index) => (
                  <span 
                    key={index}
                    className="bg-white text-gray-700 px-3 py-1 rounded-lg text-sm border border-orange-200"
                  >
                    {topic}
                  </span>
                ))}
              </div>
            </div>
          </div>

          {/* Детали активной недели */}
          <div className="lg:col-span-2">
            <WeekDetail week={activeWeekPlan} />
            
            {/* Ресурсы */}
            <div className="mt-6">
              <h3 className="font-semibold text-gray-900 mb-3">Рекомендуемые материалы</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {filteredResources.length > 0 ? (
                  filteredResources.map((resource, index) => (
                    <ResourceCard key={resource.id || index} resource={resource} />
                  ))
                ) : (
                  <div className="col-span-2 text-center py-4 text-gray-500">
                    Нет материалов для этой недели
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>

        {/* Кнопки действий */}
        <div className="flex justify-between items-center mt-8 pt-6 border-t">
          {onRegenerate && (
            <Button 
              onClick={onRegenerate}
              variant="outline"
              className="px-6"
            >
              Сгенерировать новый план
            </Button>
          )}
          
          <Button 
            onClick={onAccept}
            className="px-8 bg-gradient-to-r from-green-600 to-blue-600 hover:from-green-700 hover:to-blue-700 text-white"
          >
            Начать обучение по плану
          </Button>
        </div>
      </div>
    </Card>
  );
};

// Компонент деталей недели
const WeekDetail: React.FC<{ week: WeekPlan | null }> = ({ week }) => {
  if (!week) {
    return (
      <div className="bg-white border border-gray-200 rounded-xl p-5 text-center">
        <p className="text-gray-500">Информация о неделе недоступна</p>
      </div>
    );
  }

  return (
    <div className="bg-white border border-gray-200 rounded-xl p-5">
      <div className="flex items-center justify-between mb-4">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">
            Неделя {week.weekNumber}
          </h3>
          <div className={`inline-flex items-center px-2 py-1 rounded-full text-xs font-medium mt-1 ${
            week.difficulty === 'basic' 
              ? 'bg-green-100 text-green-800' 
              : week.difficulty === 'intermediate'
              ? 'bg-yellow-100 text-yellow-800'
              : 'bg-red-100 text-red-800'
          }`}>
            {week.difficulty === 'basic' ? 'Начальный уровень' :
             week.difficulty === 'intermediate' ? 'Средний уровень' : 'Продвинутый уровень'}
          </div>
        </div>
        <div className="bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm font-medium">
          {week.practiceHours} часов практики
        </div>
      </div>

      {/* Темы для изучения */}
      <div className="mb-4">
        <h4 className="font-medium text-gray-900 mb-2">Темы для изучения:</h4>
        <div className="flex flex-wrap gap-2">
          {(week.themes || []).length > 0 ? (
            week.themes.map((theme, index) => (
              <span 
                key={index}
                className="bg-gray-100 text-gray-700 px-3 py-1 rounded-lg text-sm"
              >
                {theme}
              </span>
            ))
          ) : (
            <span className="text-gray-500 text-sm">Темы не указаны</span>
          )}
        </div>
      </div>

      {/* Задачи на неделю */}
      <div className="mb-4">
        <h4 className="font-medium text-gray-900 mb-2">Задачи на неделю:</h4>
        <ul className="space-y-2">
          {(week.tasks || []).length > 0 ? (
            week.tasks.map((task, index) => (
              <li key={index} className="flex items-start space-x-2 text-sm">
                <span className="text-blue-600 mt-0.5">•</span>
                <span className="text-gray-700">{task}</span>
              </li>
            ))
          ) : (
            <li className="text-sm text-gray-500">Задачи не назначены</li>
          )}
        </ul>
      </div>

      {/* Цели недели */}
      <div>
        <h4 className="font-medium text-gray-900 mb-2">Цели недели:</h4>
        <ul className="space-y-1">
          {(week.goals || []).length > 0 ? (
            week.goals.map((goal, index) => (
              <li key={index} className="flex items-start space-x-2 text-sm">
                <span className="text-green-600 mt-0.5">✓</span>
                <span className="text-gray-700">{goal}</span>
              </li>
            ))
          ) : (
            <li className="text-sm text-gray-500">Цели не установлены</li>
          )}
        </ul>
      </div>
    </div>
  );
};

// Компонент карточки ресурса
const ResourceCard: React.FC<{ resource: Resource }> = ({ resource }) => {
  if (!resource) return null;

  const getTypeInfo = (type: string) => {
    switch (type) {
      case 'textbook':
        return { 
          icon: '📚', 
          class: 'bg-blue-100 text-blue-800',
          label: 'Учебник'
        };
      case 'video':
        return { 
          icon: '🎥', 
          class: 'bg-green-100 text-green-800',
          label: 'Видео'
        };
      case 'practice':
        return { 
          icon: '💻', 
          class: 'bg-yellow-100 text-yellow-800',
          label: 'Практика'
        };
      case 'test':
        return { 
          icon: '📝', 
          class: 'bg-purple-100 text-purple-800',
          label: 'Тест'
        };
      default:
        return { 
          icon: '📖', 
          class: 'bg-gray-100 text-gray-800',
          label: 'Материал'
        };
    }
  };

  const getDifficultyInfo = (difficulty: string) => {
    switch (difficulty) {
      case 'basic':
        return { class: 'bg-green-100 text-green-800', label: 'Начальный' };
      case 'intermediate':
        return { class: 'bg-yellow-100 text-yellow-800', label: 'Средний' };
      case 'advanced':
        return { class: 'bg-red-100 text-red-800', label: 'Продвинутый' };
      default:
        return { class: 'bg-gray-100 text-gray-800', label: 'Любой' };
    }
  };

  const typeInfo = getTypeInfo(resource.type);
  const difficultyInfo = getDifficultyInfo(resource.difficulty);

  return (
    <div className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow">
      <div className="flex items-start justify-between mb-2">
        <div className="flex items-center space-x-2">
          <span className={`text-xs font-medium px-2 py-1 rounded-full ${typeInfo.class}`}>
            {typeInfo.icon} {typeInfo.label}
          </span>
          <span className={`text-xs font-medium px-2 py-1 rounded-full ${difficultyInfo.class}`}>
            {difficultyInfo.label}
          </span>
        </div>
        {resource.duration && (
          <span className="text-xs text-gray-500 bg-gray-100 px-2 py-1 rounded">
            {resource.duration} мин
          </span>
        )}
      </div>
      
      <h4 className="text-sm font-medium text-gray-900 mb-2">
        {resource.title || 'Без названия'}
      </h4>
      
      <p className="text-xs text-gray-600 mb-3">
        {resource.description || 'Описание отсутствует'}
      </p>

      {resource.topics && resource.topics.length > 0 && (
        <div className="flex flex-wrap gap-1">
          {resource.topics.slice(0, 2).map((topic, index) => (
            <span 
              key={index}
              className="text-xs bg-blue-50 text-blue-700 px-2 py-1 rounded"
            >
              {topic}
            </span>
          ))}
          {resource.topics.length > 2 && (
            <span className="text-xs text-gray-500">
              +{resource.topics.length - 2}
            </span>
          )}
        </div>
      )}
    </div>
  );
};

export default StudyPlanView;