// src/components/assessment/GoalSetting.tsx
'use client';

import { useState } from 'react';
import { StudyPlanUtils } from '@/lib/utils/studyPlanUtils';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';

interface GoalSettingProps {
  currentScore: number;
  onGoalsSet: () => void;
}

export const GoalSetting: React.FC<GoalSettingProps> = ({ currentScore, onGoalsSet }) => {
  const [targetScore, setTargetScore] = useState(currentScore + 15);
  const [availableHours, setAvailableHours] = useState(10);
  const [examDate, setExamDate] = useState('');

  const handleSubmit = () => {
    // Сохраняем данные пользователя
    const userProfile = {
      initialScore: currentScore,
      targetScore: targetScore,
      availableHours: availableHours,
      examDate: examDate || new Date(Date.now() + 90 * 24 * 60 * 60 * 1000).toISOString(),
      subjects: ['Математика']
    };

    console.log('💾 Saving user profile:', userProfile);
    
    StudyPlanUtils.saveUserProfile(userProfile);
    
    // Проверяем что сохранилось
    const savedProfile = StudyPlanUtils.getUserProfile();
    console.log('✅ Saved profile verification:', savedProfile);
    
    // Проверяем полные данные для плана
    const planData = StudyPlanUtils.getPlanGenerationData();
    console.log('📋 Full plan data:', planData);
    
    onGoalsSet();
  };

  const getDateInThreeMonths = () => {
    const date = new Date();
    date.setMonth(date.getMonth() + 3);
    return date.toISOString().split('T')[0];
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
      <Card className="max-w-2xl w-full mx-auto p-8">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Настройте цели обучения</h1>
          <p className="text-gray-600">Укажите ваши цели для создания персонализированного плана</p>
        </div>
        
        <div className="space-y-8">
          {/* Текущий и целевой балл */}
          <div className="bg-blue-50 rounded-2xl p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Целевой балл</h2>
            <div className="space-y-4">
              <div className="flex justify-between text-sm text-gray-600">
                <span>Текущий балл: <strong className="text-blue-600">{currentScore}%</strong></span>
                <span>Целевой балл: <strong className="text-green-600">{targetScore}%</strong></span>
              </div>
              
              <input
                type="range"
                min={Math.min(currentScore + 5, 95)}
                max={95}
                value={targetScore}
                onChange={(e) => setTargetScore(Number(e.target.value))}
                className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
              />
              
              <div className="flex justify-between text-xs text-gray-500">
                <span>+5%</span>
                <span>+{targetScore - currentScore}%</span>
                <span>+{95 - currentScore}%</span>
              </div>
            </div>
          </div>

          {/* Время на подготовку */}
          <div className="bg-green-50 rounded-2xl p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Время на подготовку</h2>
            <div className="space-y-4">
              <div className="text-center">
                <span className="text-2xl font-bold text-green-600">{availableHours}</span>
                <span className="text-gray-600 ml-2">часов в неделю</span>
              </div>
              
              <input
                type="range"
                min={5}
                max={20}
                step={1}
                value={availableHours}
                onChange={(e) => setAvailableHours(Number(e.target.value))}
                className="w-full h-3 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
              />
              
              <div className="flex justify-between text-xs text-gray-500">
                <span>5 ч/нед</span>
                <span>Средняя нагрузка</span>
                <span>20 ч/нед</span>
              </div>
            </div>
          </div>

          {/* Дата экзамена */}
          <div className="bg-purple-50 rounded-2xl p-6">
            <h2 className="text-xl font-semibold text-gray-900 mb-4">Дата экзамена</h2>
            <div className="space-y-3">
              <input
                type="date"
                value={examDate}
                onChange={(e) => setExamDate(e.target.value)}
                min={new Date().toISOString().split('T')[0]}
                className="w-full p-4 border border-gray-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Выберите дату экзамена"
              />
              <p className="text-sm text-gray-500">
                {examDate ? `Экзамен через ${Math.ceil((new Date(examDate).getTime() - Date.now()) / (1000 * 60 * 60 * 24))} дней` : 'Рекомендуем указать дату для более точного плана'}
              </p>
            </div>
          </div>

          {/* Кнопка создания плана */}
          <Button 
            onClick={handleSubmit}
            className="w-full py-4 text-lg font-semibold bg-gradient-to-r from-blue-600 to-indigo-600 hover:from-blue-700 hover:to-indigo-700 text-white rounded-2xl shadow-lg hover:shadow-xl transition-all transform hover:scale-105"
          >
            Создать план обучения
          </Button>

          {/* Информация о данных */}
          <div className="text-center text-sm text-gray-500">
            <p>На основе: текущего балла {currentScore}%, результатов тестирования и ваших целей</p>
          </div>
        </div>
      </Card>
    </div>
  );
};