// src/components/assessment/Assessment.tsx
'use client';

import { useState, useEffect } from 'react';
import { Card } from '@/components/ui/Card';
import { QuestionCard } from './QuestionCard';
import { AssessmentQuestion, AssessmentResult } from '@/types/assessment.types';
import { getBalancedQuestions } from '@/lib/constants/questions';

interface AssessmentProps {
  onComplete: (result: AssessmentResult) => void;
}

export const Assessment: React.FC<AssessmentProps> = ({ onComplete }) => {
  const [questions, setQuestions] = useState<AssessmentQuestion[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [selected, setSelected] = useState<string | null>(null);

  useEffect(() => {
    console.log('Loading questions...');
    const loadedQuestions = getBalancedQuestions();
    setQuestions(loadedQuestions);
    console.log('Questions loaded:', loadedQuestions.length);
  }, []);

  const handleSelect = (answer: string) => {
    console.log('Assessment: Answer selected:', answer);
    setSelected(answer);
    
    setTimeout(() => {
      console.log('Moving to next question...');
      if (currentIndex < questions.length - 1) {
        setCurrentIndex(prev => prev + 1);
        setSelected(null);
      } else {
        console.log('Test completed');
        onComplete({
          estimatedScore: 75,
          totalCorrect: 10,
          totalQuestions: questions.length,
          themeBreakdown: [],
          recommendedFocus: [],
          preparationLevel: 'intermediate',
          totalPoints: 0,
          maxPossiblePoints: 0
        });
      }
    }, 500);
  };

  if (questions.length === 0) {
    return <div className="p-8 text-center">Загрузка вопросов...</div>;
  }

  const currentQuestion = questions[currentIndex];

  return (
    <div className="max-w-2xl mx-auto p-4">
      <Card>
        <div className="p-6">
          <div className="text-center mb-6">
            <h2 className="text-2xl font-bold mb-2">Тестирование</h2>
            <p>Вопрос {currentIndex + 1} из {questions.length}</p>
          </div>

          <QuestionCard
            question={currentQuestion}
            selectedAnswer={selected}
            onAnswerSelect={handleSelect}
            questionNumber={currentIndex + 1}
            totalQuestions={questions.length}
          />
        </div>
      </Card>
    </div>
  );
};