// src/app/learning/plan/page.tsx
'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import { StudyPlanView } from '@/components/study-plan/StudyPlanView';
import { StudyPlanUtils } from '@/lib/utils/studyPlanUtils';
import { generateStudyPlan } from '@/lib/services/studyPlanGenerator';
import type { StudyPlan } from '@/types/plan';

export default function LearningPlanPage() {
  const router = useRouter();
  const [plan, setPlan] = useState<StudyPlan | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const generatePlan = async () => {
      try {
        setLoading(true);
        setError(null);
        
        // Получаем данные из localStorage
        const planData = StudyPlanUtils.getPlanGenerationData();
        
        if (!planData) {
          setError('Данные для генерации плана не найдены. Пожалуйста, пройдите тестирование сначала.');
          return;
        }

        // Проверяем, что есть необходимые данные
        if (!planData.weakThemes || planData.weakThemes.length === 0) {
          setError('Не найдены данные о слабых темах. Пожалуйста, пройдите тестирование заново.');
          return;
        }

        if (planData.initialScore === undefined || planData.targetScore === undefined) {
          setError('Не найдены данные о текущем и целевом балле. Пожалуйста, завершите регистрацию.');
          return;
        }

        // Генерируем план
        const generatedPlan = await generateStudyPlan(planData);
        
        if (!generatedPlan) {
          setError('Не удалось сгенерировать план обучения. Пожалуйста, попробуйте еще раз.');
          return;
        }
        
        setPlan(generatedPlan);
        
      } catch (err) {
        console.error('Plan generation error:', err);
        setError('Ошибка при генерации плана обучения. Пожалуйста, попробуйте еще раз.');
      } finally {
        setLoading(false);
      }
    };

    // Добавляем небольшую задержку для лучшего UX
    const timer = setTimeout(() => {
      generatePlan();
    }, 500);

    return () => clearTimeout(timer);
  }, []);

  const handleAcceptPlan = async () => {
    try {
      // Сохраняем план в localStorage
      if (plan) {
        StudyPlanUtils.saveAcceptedPlan(plan);
        
        // Здесь можно добавить API вызов для сохранения в базу данных
        console.log('Plan accepted and saved:', plan);
        
        // Показываем успешное сообщение перед переходом
        setTimeout(() => {
          router.push('/dashboard');
        }, 1000);
      }
    } catch (err) {
      console.error('Error saving plan:', err);
      setError('Ошибка при сохранении плана');
    }
  };

  const handleRegeneratePlan = async () => {
    setLoading(true);
    setError(null);
    
    try {
      const planData = StudyPlanUtils.getPlanGenerationData();
      if (planData) {
        const newPlan = await generateStudyPlan(planData);
        if (newPlan) {
          setPlan(newPlan);
        } else {
          setError('Не удалось перегенерировать план');
        }
      } else {
        setError('Данные для генерации плана не найдены');
      }
    } catch (err) {
      console.error('Regeneration error:', err);
      setError('Ошибка при перегенерации плана');
    } finally {
      setLoading(false);
    }
  };

  const handleGoToAssessment = () => {
    router.push('/assessment');
  };

  const handleGoToRegistration = () => {
    router.push('/register');
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Создаем ваш персональный план обучения</h2>
          <p className="text-gray-600">Анализируем ваши результаты и подбираем оптимальную программу...</p>
        </div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-lg">
          <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl text-red-600">⚠️</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Недостаточно данных</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          
          <div className="space-y-3">
            <button
              onClick={handleGoToAssessment}
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
            >
              Пройти тестирование
            </button>
            
            <button
              onClick={handleGoToRegistration}
              className="w-full bg-green-600 text-white py-3 rounded-xl font-semibold hover:bg-green-700 transition-colors"
            >
              Завершить регистрацию
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (!plan) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <div className="bg-white rounded-2xl p-8 max-w-md w-full text-center shadow-lg">
          <div className="w-16 h-16 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <span className="text-2xl text-yellow-600">📚</span>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">План не сгенерирован</h2>
          <p className="text-gray-600 mb-6">Для создания плана обучения необходимо пройти регистрацию и тестирование</p>
          
          <div className="space-y-3">
            <button
              onClick={handleGoToRegistration}
              className="w-full bg-blue-600 text-white py-3 rounded-xl font-semibold hover:bg-blue-700 transition-colors"
            >
              Зарегистрироваться
            </button>
            
            <button
              onClick={handleGoToAssessment}
              className="w-full bg-green-600 text-white py-3 rounded-xl font-semibold hover:bg-green-700 transition-colors"
            >
              Пройти тестирование
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-6xl mx-auto">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Ваш персональный план обучения</h1>
          <p className="text-gray-600">План разработан на основе ваших результатов тестирования и целей</p>
        </div>
        
        <StudyPlanView 
          plan={plan}
          onAccept={handleAcceptPlan}
          onRegenerate={handleRegeneratePlan}
        />
      </div>
    </div>
  );
}