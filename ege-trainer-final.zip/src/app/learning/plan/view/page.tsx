// src/app/learning/plan/view/page.tsx
'use client';

import { useApp } from '@/context/AppContext';
import { Card } from '@/components/ui/Card';
import { Button } from '@/components/ui/Button';
import { useRouter } from 'next/navigation';

export default function PlanViewPage() {
  const { user } = useApp();
  const router = useRouter();

  if (!user?.studyPlan) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 flex items-center justify-center p-4">
        <Card className="max-w-md w-full mx-auto p-8 text-center shadow-lg">
          <div className="w-16 h-16 mx-auto mb-4 bg-blue-100 rounded-full flex items-center justify-center">
            <svg className="w-8 h-8 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-2.5L13.732 4c-.77-.833-1.964-.833-2.732 0L4.082 16.5c-.77.833.192 2.5 1.732 2.5z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-4">План не найден</h2>
          <p className="text-gray-600 mb-6">Пожалуйста, сначала создайте план обучения</p>
          <Button onClick={() => router.push('/learning/plan')} className="w-full">
            Создать план
          </Button>
        </Card>
      </div>
    );
  }

  const { studyPlan } = user;
  const weakThemes = user.knowledgeMap?.weakThemes || [];

  // Структура плана подготовки
  const preparationPlan = {
    duration: "16 недель",
    weeklyHours: "10 часов в неделю",
    totalThemes: weakThemes.length,
    examDate: "30.12.2025", // Используем фиксированную дату или получаем из другого места
    methodology: [
      "Поэтапное изучение тем от простого к сложному",
      "Регулярное повторение и закрепление материала",
      "Практические задания после каждой темы",
      "Промежуточное тестирование для контроля прогресса"
    ],
    weeklyStructure: [
      { day: "Понедельник", activity: "Изучение новой теории (2 часа)" },
      { day: "Вторник", activity: "Решение практических задач (3 часа)" },
      { day: "Среда", activity: "Повторение пройденного (2 часа)" },
      { day: "Четверг", activity: "Новая тема/углубление (2 часа)" },
      { day: "Пятница", activity: "Тестирование и анализ ошибок (1 час)" },
      { day: "Суббота", activity: "Отдых или повторение по желанию" },
      { day: "Воскресенье", activity: "Отдых" }
    ],
    themesSchedule: [
      { weeks: "1-4", theme: "Базовые темы", description: "Закрепление фундаментальных знаний" },
      { weeks: "5-8", theme: "Основные разделы", description: "Изучение ключевых тем ЕГЭ" },
      { weeks: "9-12", theme: "Сложные задачи", description: "Решение задач повышенной сложности" },
      { weeks: "13-16", theme: "Повторение и пробники", description: "Закрепление и пробные экзамены" }
    ]
  };

  const handleStartLearning = () => {
    router.push('/learning/themes');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Основная информация о плане */}
        <Card className="p-8 mb-8 shadow-xl border-0">
          <div className="text-center mb-8">
            <div className="w-20 h-20 mx-auto mb-4 bg-gradient-to-r from-blue-500 to-indigo-600 rounded-full flex items-center justify-center shadow-lg">
              <svg className="w-10 h-10 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <h1 className="text-4xl font-bold text-gray-900 mb-4">
              Персонализированный план подготовки к ЕГЭ
            </h1>
            <p className="text-xl text-gray-600 mb-6">
              Целевой балл: <span className="font-semibold text-blue-600">{studyPlan.targetScore}%</span>
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
            <div className="bg-gradient-to-br from-blue-500 to-blue-600 rounded-xl p-4 text-white text-center">
              <div className="text-2xl font-bold mb-1">{preparationPlan.duration}</div>
              <div className="text-blue-100 text-sm">Продолжительность</div>
            </div>
            <div className="bg-gradient-to-br from-green-500 to-green-600 rounded-xl p-4 text-white text-center">
              <div className="text-2xl font-bold mb-1">{preparationPlan.weeklyHours}</div>
              <div className="text-green-100 text-sm">Интенсивность</div>
            </div>
            <div className="bg-gradient-to-br from-purple-500 to-purple-600 rounded-xl p-4 text-white text-center">
              <div className="text-2xl font-bold mb-1">{preparationPlan.totalThemes}</div>
              <div className="text-purple-100 text-sm">Тем для изучения</div>
            </div>
            <div className="bg-gradient-to-br from-orange-500 to-orange-600 rounded-xl p-4 text-white text-center">
              <div className="text-2xl font-bold mb-1">{preparationPlan.examDate}</div>
              <div className="text-orange-100 text-sm">Дата экзамена</div>
            </div>
          </div>

          <Button 
            onClick={handleStartLearning}
            className="w-full py-4 text-lg font-medium bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 shadow-lg transition-all duration-200"
          >
            <svg className="w-6 h-6 mr-2" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14.752 11.168l-3.197-2.132A1 1 0 0010 9.87v4.263a1 1 0 001.555.832l3.197-2.132a1 1 0 000-1.664z" />
            </svg>
            Начать обучение
          </Button>
        </Card>

        {/* Методология обучения */}
        <Card className="p-8 mb-8 shadow-xl border-0">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <svg className="w-6 h-6 mr-2 text-blue-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            Методология подготовки
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {preparationPlan.methodology.map((item, index) => (
              <div key={index} className="flex items-start p-4 bg-blue-50 rounded-lg">
                <div className="w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center mr-3 flex-shrink-0">
                  <span className="text-white font-bold text-sm">{index + 1}</span>
                </div>
                <p className="text-gray-700">{item}</p>
              </div>
            ))}
          </div>
        </Card>

        {/* Расписание по неделям */}
        <Card className="p-8 mb-8 shadow-xl border-0">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <svg className="w-6 h-6 mr-2 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
            </svg>
            Этапы подготовки
          </h2>
          <div className="space-y-4">
            {preparationPlan.themesSchedule.map((stage, index) => (
              <div key={index} className="flex items-start p-6 bg-white border border-gray-200 rounded-xl hover:border-green-300 transition-colors">
                <div className="w-12 h-12 bg-green-100 rounded-lg flex items-center justify-center mr-4 flex-shrink-0">
                  <span className="text-green-600 font-bold">{stage.weeks}</span>
                </div>
                <div className="flex-1">
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{stage.theme}</h3>
                  <p className="text-gray-600">{stage.description}</p>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Еженедельное расписание */}
        <Card className="p-8 shadow-xl border-0">
          <h2 className="text-2xl font-bold text-gray-900 mb-6 flex items-center">
            <svg className="w-6 h-6 mr-2 text-purple-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Еженедельное расписание
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {preparationPlan.weeklyStructure.map((day, index) => (
              <div key={index} className={`p-4 rounded-lg ${
                day.activity.includes('Отдых') 
                  ? 'bg-gray-50 text-gray-600' 
                  : 'bg-purple-50 text-gray-700'
              }`}>
                <div className="font-semibold text-purple-600 mb-1">{day.day}</div>
                <div>{day.activity}</div>
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}