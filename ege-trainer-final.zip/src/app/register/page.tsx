// src/app/register/page.tsx
'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { useApp } from '@/context/AppContext';
import type { User, Intensity } from '@/types';
import { StudyPlanUtils } from '@/lib/utils/studyPlanUtils';

const subjectsList = ['Математика', 'Физика', 'Химия', 'Биология'];

export default function Register() {
  const router = useRouter();
  const { setUser } = useApp();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    email: '',
    profile: {
      targetScore: 80,
      deadline: '2024-06-01',
      preferredIntensity: 'medium' as Intensity,
      subjects: [] as string[],
      grade: 11
    }
  });

  const handleSubjectToggle = (subject: string) => {
    setFormData(prev => ({
      ...prev,
      profile: {
        ...prev.profile,
        subjects: prev.profile.subjects.includes(subject)
          ? prev.profile.subjects.filter(s => s !== subject)
          : [...prev.profile.subjects, subject]
      }
    }));
  };
  const handleRegistration = (userData: {
  initialScore: number;
  targetScore: number;
  availableHours: number;
  examDate: string;
  subjects: string[];
}) => {
  // Сохраняем данные пользователя
  StudyPlanUtils.saveUserProfile(userData);
  
  // Перенаправляем на тестирование
  router.push('/assessment');
};

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const user: User = {
        id: Math.random().toString(36).substr(2, 9),
        email: formData.email,
        profile: formData.profile,
        createdAt: new Date()
      };
      
      setUser(user);
      console.log('User registered:', user);
      router.push('/assessment');
    } catch (error) {
      console.error('Registration error:', error);
    }
  };

  // Progress steps
  const steps = [
    { number: 1, title: 'Основная информация' },
    { number: 2, title: 'Выбор предметов' },
    { number: 3, title: 'Настройки подготовки' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-8 px-4">
      <div className="max-w-lg mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-gray-900 mb-3">
            Регистрация
          </h1>
          <p className="text-lg text-gray-600 max-w-md mx-auto">
            Составьте свой персональный план подготовки к ЕГЭ
          </p>
        </div>

        {/* Progress Steps */}
        <div className="flex justify-center mb-8">
          <div className="flex items-center space-x-4">
            {steps.map((stepItem, index) => (
              <div key={stepItem.number} className="flex items-center">
                <div className={`flex items-center justify-center w-10 h-10 rounded-full border-2 ${
                  step >= stepItem.number
                    ? 'bg-blue-600 border-blue-600 text-white'
                    : 'border-gray-300 text-gray-400'
                } font-semibold`}>
                  {stepItem.number}
                </div>
                {index < steps.length - 1 && (
                  <div className={`w-12 h-0.5 ${
                    step > stepItem.number ? 'bg-blue-600' : 'bg-gray-300'
                  }`} />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Form Container */}
        <div className="bg-white rounded-2xl shadow-xl p-8 mb-6">
          <form onSubmit={handleSubmit} className="space-y-6">
            {/* Step 1: Basic Info */}
            {step === 1 && (
              <div className="space-y-6">
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">
                    Основная информация
                  </h2>
                  <p className="text-gray-500">
                    Введите ваш email для начала работы
                  </p>
                </div>
                
                <div>
                  <label className="block text-sm font-semibold text-gray-700 mb-3">
                    Электронная почта
                  </label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className="w-full px-4 py-3 border border-gray-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
                    placeholder="your@email.com"
                    required
                  />
                </div>

                <button
                  type="button"
                  onClick={() => setStep(2)}
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-700 hover:to-indigo-700 transition-all shadow-lg hover:shadow-xl"
                >
                  Далее
                </button>
              </div>
            )}

            {/* Step 2: Subjects */}
            {step === 2 && (
              <div className="space-y-6">
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">
                    Выбор предметов
                  </h2>
                  <p className="text-gray-500">
                    Выберите предметы для подготовки
                  </p>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  {subjectsList.map(subject => (
                    <button
                      key={subject}
                      type="button"
                      onClick={() => handleSubjectToggle(subject)}
                      className={`p-4 border-2 rounded-xl text-sm font-semibold transition-all ${
                        formData.profile.subjects.includes(subject)
                          ? 'bg-blue-50 border-blue-500 text-blue-700 shadow-md'
                          : 'bg-white border-gray-200 text-gray-700 hover:border-blue-300 hover:shadow-md'
                      }`}
                    >
                      {subject}
                    </button>
                  ))}
                </div>

                <div className="flex space-x-4">
                  <button
                    type="button"
                    onClick={() => setStep(1)}
                    className="flex-1 bg-gray-100 text-gray-700 py-3 px-6 rounded-xl font-semibold hover:bg-gray-200 transition-all"
                  >
                    Назад
                  </button>
                  <button
                    type="button"
                    onClick={() => setStep(3)}
                    disabled={formData.profile.subjects.length === 0}
                    className="flex-1 bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-blue-700 hover:to-indigo-700 transition-all shadow-lg hover:shadow-xl disabled:opacity-50 disabled:cursor-not-allowed"
                  >
                    Далее
                  </button>
                </div>
              </div>
            )}

            {/* Step 3: Settings */}
            {step === 3 && (
              <div className="space-y-8">
                <div className="text-center">
                  <h2 className="text-2xl font-bold text-gray-900 mb-2">
                    Настройки подготовки
                  </h2>
                  <p className="text-gray-500">
                    Настройте параметры вашего обучения
                  </p>
                </div>
                
                {/* Target Score */}
                <div className="space-y-4">
                  <div className="flex justify-between items-center">
                    <label className="text-sm font-semibold text-gray-700">
                      {formData.profile.subjects.length === 1 
                        ? `Текущий балл по ${formData.profile.subjects[0].toLowerCase()}`
                        : 'Целевой балл'
                      }
                    </label>
                    <span className="text-2xl font-bold text-blue-600">
                      {formData.profile.targetScore}
                    </span>
                  </div>
                  <input
                    type="range"
                    min="60"
                    max="100"
                    step="5"
                    value={formData.profile.targetScore}
                    onChange={(e) => setFormData(prev => ({
                      ...prev,
                      profile: { ...prev.profile, targetScore: Number(e.target.value) }
                    }))}
                    className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer [&::-webkit-slider-thumb]:appearance-none [&::-webkit-slider-thumb]:h-4 [&::-webkit-slider-thumb]:w-4 [&::-webkit-slider-thumb]:rounded-full [&::-webkit-slider-thumb]:bg-blue-600"
                  />
                  <div className="flex justify-between text-xs text-gray-500 px-1">
                    <span>60</span>
                    <span>70</span>
                    <span>80</span>
                    <span>90</span>
                    <span>100</span>
                  </div>
                </div>

                {/* Intensity */}
                <div className="space-y-4">
                  <label className="block text-sm font-semibold text-gray-700">
                    Интенсивность вашей подготовки
                  </label>
                  <div className="grid grid-cols-3 gap-3">
                    {(['low', 'medium', 'high'] as Intensity[]).map(intensity => (
                      <button
                        key={intensity}
                        type="button"
                        onClick={() => setFormData(prev => ({
                          ...prev,
                          profile: { ...prev.profile, preferredIntensity: intensity }
                        }))}
                        className={`p-4 border-2 rounded-xl text-sm font-semibold transition-all ${
                          formData.profile.preferredIntensity === intensity
                            ? intensity === 'low' 
                              ? 'bg-green-50 border-green-500 text-green-700'
                              : intensity === 'medium'
                              ? 'bg-blue-50 border-blue-500 text-blue-700'
                              : 'bg-red-50 border-red-500 text-red-700'
                            : 'bg-white border-gray-200 text-gray-700 hover:border-blue-300'
                        }`}
                      >
                        {intensity === 'low' && 'Низкая'}
                        {intensity === 'medium' && 'Средняя'}
                        {intensity === 'high' && 'Высокая'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex space-x-4">
                  <button
                    type="button"
                    onClick={() => setStep(2)}
                    className="flex-1 bg-gray-100 text-gray-700 py-3 px-6 rounded-xl font-semibold hover:bg-gray-200 transition-all"
                  >
                    Назад
                  </button>
                  <button
                    type="submit"
                    className="flex-1 bg-gradient-to-r from-green-500 to-emerald-600 text-white py-3 px-6 rounded-xl font-semibold hover:from-green-600 hover:to-emerald-700 transition-all shadow-lg hover:shadow-xl"
                  >
                    Начать тестирование
                  </button>
                </div>
              </div>
            )}
          </form>
        </div>

        {/* Footer Info */}
        <div className="text-center text-sm text-gray-500">
          <p>Уже есть аккаунт? <a href="#" className="text-blue-600 hover:text-blue-700 font-medium">Войти</a></p>
        </div>
      </div>
    </div>
  );
}